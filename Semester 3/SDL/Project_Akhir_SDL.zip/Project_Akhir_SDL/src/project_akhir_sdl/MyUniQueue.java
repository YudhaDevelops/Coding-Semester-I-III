package project_akhir_sdl;

public class MyUniQueue {
    doubleHeadedLinkedList_generic unique;

    public MyUniQueue() {
        unique = new doubleHeadedLinkedList_generic();
    }
    
    public <T> void add(T data) {
        if (unique.searchData(((Antrian)data).getId_antrian()) == false) {
            unique.addTail(data);
        }else{
            System.out.println("Id Sudah Terpakai");
        }
    }
    
    public void remove() {
        unique.delHead();
    }
    
    public void addData(String id_antrian, String nama, String keperluan){
        Antrian a = new Antrian(id_antrian, nama,keperluan);
        add(a);
    }
    
    public <T> Object peek() {
        return unique.getData(0);
    }
    
    public int getSize() {
        return unique.getSize();
    }
    
    public boolean isEmpty() {
        return unique.isEmpty();
    }
    
    public boolean isFull() {
        return unique.isEmpty();
    }

    @Override
    public String toString() {
        return unique.toString();
    }

}
