package project_akhir_sdl;
public class Antrian {
    protected String id_antrian;
    protected String nama;
    protected String keperluan;

    public Antrian() {
    }

    public Antrian(String id_antrian, String nama, String keperluan) {
        this.id_antrian = id_antrian;
        this.nama = nama;
        this.keperluan = keperluan;
    }

    public String getId_antrian() {
        return id_antrian;
    }

    public void setId_antrian(String id_antrian) {
        this.id_antrian = id_antrian;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getKeperluan() {
        return keperluan;
    }

    public void setKeperluan(String keperluan) {
        this.keperluan = keperluan;
    }
    
    
}
