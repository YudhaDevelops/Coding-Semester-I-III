package project_akhir_sdl;
import java.util.Scanner;
//misalnya menampilkan data yang udah ada di dalam linked list, dalam nya ada 
//stack and queue. setelah nampilin daftar, nampilin menu.Agustina Putri: Mau 
//nampilin data keluar terus diahpus setelah itu kalau mau nambah make addTail(belakang) 
//karena urutan antrian gaboleh ditengah jadi harus addTail
//Pakai queue masuk pertama keluar pertama panggil, keluarin data, hapus
//Kalau udah jadi tambah vitur searching(optional). Dicari berdasarkan nomor utur antrian
//Memikirkan kompleksitas searchingnya, mencari yang lebih efektif, dari awal, akhihr, atau tengah
public class Main_Pogram {

    public static void main(String[] args) {
        int menu = 0, mn = 0;
        String id = "", nama = "", keperluan = "";
        Scanner input = new Scanner(System.in);
        MyUniQueue tellerList = new MyUniQueue();
        MyUniQueue csList = new MyUniQueue();
        do {
            System.out.println("=========== PROGRAM ANTRIAN BANK ===========");
            System.out.println("1. Antrian Masuk ");
            System.out.println("2. Proses Antrian Keluar");
            System.out.println("3. Lihat Antrian");
            System.out.println("4. Keluar");
            System.out.print("Masukkan keperluan :");
            menu = input.nextInt();

            if (menu == 1) {
                System.out.println("");
                System.out.println("Mau Ke Teller Atau Ke Cs?");
                System.out.println("Pilih 1 Untuk Teller");
                System.out.println("Pilih 2 Untuk CS");

                do {
                    System.out.print("Masukkan Pilihan : ");
                    mn = input.nextInt();
                    if (mn == 1) {
                        System.out.print("Masukkan Id        : \t");
                        id = input.next();
                        System.out.print("Masukkan Nama      : \t");
                        nama = input.next();
                        System.out.print("Masukkan Keperluan : \t");
                        keperluan = input.next();
                        tellerList.addData(id, nama, keperluan);
                        input.nextLine();
                        System.out.println("");
                    } else if (mn == 2) {
                        System.out.print("Masukkan Id        : \t");
                        id = input.next();
                        System.out.print("Masukkan Nama      : \t");
                        nama = input.next();
                        System.out.print("Masukkan Keperluan : \t");
                        keperluan = input.next();
                        csList.addData(id, nama, keperluan);
                        input.nextLine();
                        System.out.println("");
                    }
                } while (mn > 0 && mn <= 2);

            } else if (menu == 2) {
                System.out.println("Keluar Teller Atau CS?");
                System.out.println("Teller 1, CS 2");
                System.out.print("Masukkan Pilihan : ");
                mn = input.nextInt();
                if (mn == 1) {
                    tellerList.remove();
                }else if (mn == 2) {
                    csList.remove();
                }else{
                    System.out.println("Pilihan Tidak Ada");
                }
            } else if (menu == 3) {
                System.out.println("");
                System.out.println("Tampilan Antrian Teller");
                System.out.println(tellerList.toString());
                System.out.println("");
                System.out.println("Tampilan Antrian CS");
                System.out.println(csList.toString());
            } else if (menu == 4) {
                System.out.println("--- Terima Kasih ---");
            } else {
                System.out.println("--- Masukkan Anda Salah ---");
            }
            System.out.println("");
        } while (menu > 0 && menu <= 4);
    }
}
